using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundColor : MonoBehaviour
{
    GameObject colorPicker;
    GameObject dropdownButton;
    Camera cam;

    string colorPickerString = "FlexibleColorPicker";
    string dropdownButtonString = "Color Picker Button";

    public bool dropDownButtonAtStart;

    void Start()
    {
        colorPicker = GameObject.Find(colorPickerString);
        dropdownButton = GameObject.Find(dropdownButtonString);

        colorPicker.SetActive(false);
        dropdownButton.SetActive(dropDownButtonAtStart);

        cam = Camera.main;
        SetColor(ExtractColor());
    }

    public void ShowColorPicker()
    {
        colorPicker.SetActive(true);
        dropdownButton.SetActive(false);
    }

    public void ChangeColor()
    {
        Color color = colorPicker.GetComponent<FlexibleColorPicker>().color;
        SetColor(color);
        PlayerPrefs.SetString("BgColor", color.ToString());
    }

    void SetColor(Color color)
    {
        cam.GetComponent<Camera>().backgroundColor = color;
    }
 
    Color ExtractColor()
    {
        string str_color = PlayerPrefs.GetString("BgColor", "RGBA(0.000, 0.000, 0.000, 1.000)");

        //Remove the header and brackets
        str_color = str_color.Replace("RGBA(", "");
        str_color = str_color.Replace(")", "");

        //Get the individual values (red green blue and alpha)
        var strings = str_color.Split(","[0]);

        Color outputcolor;
        outputcolor = Color.black;
        for (var i = 0; i < 4; i++)
        {
            outputcolor[i] = System.Single.Parse(strings[i]);
        }

        return outputcolor;
    }
}
