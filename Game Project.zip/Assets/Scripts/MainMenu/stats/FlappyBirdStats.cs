using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlappyBirdStats : Statistics
{
    string highscore=" high score";
    
    private void Awake() {
        gameName="flappy bird";
        base.NewGame(gameName);
    }
    
    public int GetHighScore(){
        return PlayerPrefs.GetInt(gameName+highscore,0);
    }

    public void SetHighScore(int newScore){
        if(newScore>GetHighScore())
            PlayerPrefs.SetInt(gameName+highscore,newScore);
    }
}
