using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Statistics : MonoBehaviour
{
    protected string gameName;
    protected string gamesPlayed=" games played";

    public int GetGamesPlayed(){
        return PlayerPrefs.GetInt(gameName+gamesPlayed,0);
    }

    public void NewGame(string gameName){
        if(SceneManager.GetActiveScene().name=="MainMenu")  return;
        PlayerPrefs.SetInt(gameName+gamesPlayed,GetGamesPlayed()+1);
    }
}
