using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockBreakerStats : Statistics
{
    string brokenBlocks=" blocks broken";
    string powerupsCollector=" powerups collected";
    string ballsSpawned=" balls spawned";

    private void Awake() {
        gameName="block breaker";
        base.NewGame(gameName);
    }

    public int GetBlocksBroken(){
        return PlayerPrefs.GetInt(gameName+brokenBlocks);
    }

    public void BreakABlock(){
        PlayerPrefs.SetInt(gameName+brokenBlocks,GetBlocksBroken()+1);
    }

    public int GetPowerupCollected(){
        return PlayerPrefs.GetInt(gameName+powerupsCollector,0);
    }

    public void CollectPowerup(){
        PlayerPrefs.SetInt(gameName+powerupsCollector,GetPowerupCollected()+1);
    }

    public int GetBallsSpawned(){
        return PlayerPrefs.GetInt(gameName+ballsSpawned,0);
    }

    public void AddSpawnedBalls(int num){
        PlayerPrefs.SetInt(gameName+ballsSpawned,GetBallsSpawned()+num);
    }
}
