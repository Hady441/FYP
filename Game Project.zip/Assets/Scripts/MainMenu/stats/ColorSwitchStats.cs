using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorSwitchStats : Statistics
{
    string highscore=" high score";

    private void Awake() {
        gameName="color switch";
        base.NewGame(gameName);
    }

    public int GetHighScore(){
        return PlayerPrefs.GetInt(gameName+highscore,0);
    }

    public void SetHighScore(int newScore){
        if(newScore>GetHighScore())
            PlayerPrefs.SetInt(gameName+highscore,newScore);
    }
}
