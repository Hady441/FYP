using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ShowStats : MonoBehaviour
{
    BlockBreakerStats blockBreakerStats;
    ColorSwitchStats colorSwitchStats;
    FlappyBirdStats flappyBirdStats;

    GameObject statsHolderUI;
    TextMeshProUGUI statsText;

    void Start()
    {
        blockBreakerStats=GetComponent<BlockBreakerStats>();
        colorSwitchStats=GetComponent<ColorSwitchStats>();
        flappyBirdStats=GetComponent<FlappyBirdStats>();

        statsHolderUI=GameObject.Find("StatsHolderUI");
        statsText=statsHolderUI.GetComponentInChildren<TextMeshProUGUI>();
        Hide();
    }

    public void Hide(){
        statsHolderUI.gameObject.SetActive(false);
    }

    public void Show(){//get games stats and show them
        statsText.SetText(ShowFlappyBirdStats()+"\n\n"+ShowColorSwitchStats()+"\n\n"+ShowBlockBreakerStats());

        statsHolderUI.gameObject.SetActive(true);
    }

    string ShowBlockBreakerStats(){
        string blockBreakerGamesPlayed="Games Played: "+blockBreakerStats.GetGamesPlayed();
        string blockBreakerBrokenBricks="Broken Bricks: "+blockBreakerStats.GetBlocksBroken();
        string blockBreakerSpawnedBalls="Spawned Balls: "+blockBreakerStats.GetBallsSpawned();
        string blockBreakerPowerupsCollected="Powerups Collected: "+blockBreakerStats.GetPowerupCollected();

        return "Block Breaker Stats:\n"+
                            "\t"+blockBreakerGamesPlayed+"\n"+
                            "\t"+blockBreakerBrokenBricks+"\n"+
                            "\t"+blockBreakerSpawnedBalls+"\n"+
                            "\t"+blockBreakerPowerupsCollected;
    }

    string ShowColorSwitchStats(){
        string colorSwitchGamesPlayed="Games Played: "+colorSwitchStats.GetGamesPlayed();
        string colorSwitchHighScore="High Score: "+colorSwitchStats.GetHighScore();

        return "Color Switch Stats:\n"+
                            "\t"+colorSwitchGamesPlayed+"\n"+
                            "\t"+colorSwitchHighScore+"\n";
    }

    string ShowFlappyBirdStats(){
        string flappyBirdGamesPlayed="Games Played: "+flappyBirdStats.GetGamesPlayed();
        string flappyBirdHighScore="High Score: "+flappyBirdStats.GetHighScore();

        return "Flappy Bird Stats:\n"+
                            "\t"+flappyBirdGamesPlayed+"\n"+
                            "\t"+flappyBirdHighScore+"\n";
    }
}
