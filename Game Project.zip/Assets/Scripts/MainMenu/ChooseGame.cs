using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChooseGame : MonoBehaviour
{
    public void GoToGame(string sceneName){
        SceneManager.LoadScene(sceneName);
    }
}
