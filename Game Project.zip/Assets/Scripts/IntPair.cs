using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//used to get horizontal and vertical position of bricks in grid
public class IntPair
{
    public int First { get; set; }
    public int Second { get; set; }

    public IntPair(int first, int second)
    {
        First = first;
        Second = second;
    }
}