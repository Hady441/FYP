using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody rb;
    SpriteRenderer spriteRenderer;

    public Material[] materials;
    
    ColorGameManager gameManager;
    UIManager uiManager;

    float jumpPower=9.0f;
    float cameraFixerPosition=12.5f;

    void Start()
    {
        rb=GetComponent<Rigidbody>();
        spriteRenderer=GetComponent<SpriteRenderer>();
        ChangeMaterial();

        gameManager=GameObject.Find("Game Manager").GetComponent<ColorGameManager>();
        uiManager=GameObject.Find("Game Manager").GetComponent<UIManager>();
    }

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)){
            rb.AddForce(Vector3.up*jumpPower,ForceMode.Impulse);
        }

        if(transform.position.y>=cameraFixerPosition){//move to next level
            float adder=12.5f;
            Camera.main.transform.position=new Vector3(0,transform.position.y+5,-15);
            cameraFixerPosition+=adder;

            gameManager.SpawnObstacle(adder);
            gameManager.SpawnColorChanger(adder);
            uiManager.UpdateScore();

            rb.velocity=Vector3.zero;
            rb.angularVelocity=Vector3.zero;
        }

        if(transform.position.y<-10)    uiManager.GameOver();
    }

    void ChangeMaterial(){//change ball color
        Material m=materials[Random.Range(0,materials.Length)];
        spriteRenderer.material=m;
        gameObject.layer=LayerMask.NameToLayer(m.name);//change ball layer to not collide with its same color
    }

    private void OnTriggerEnter(Collider other) {
        if(other.CompareTag("Color Changer")){
            Destroy(other.gameObject);
            ChangeMaterial();
        }
    }

    private void OnCollisionEnter(Collision other) {
        uiManager.GameOver();
    }
}
