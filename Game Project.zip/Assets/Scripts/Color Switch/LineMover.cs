using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineMover : MonoBehaviour
{
    Vector3 initialPos;
    float leftEdge;
    float speed;

    float minSpeed=1.5f;
    float maxSpeed=4.0f;

    void Start()
    {
        initialPos=transform.position;
        leftEdge=initialPos.x-24.0f;
        speed=Random.Range(minSpeed,maxSpeed);

        /*int i=Random.Range(-1,1);
        if(i==0)    i=1;
        speed*=i;*/
    }

    void Update()
    {
        transform.position+=Vector3.left*Time.deltaTime*speed;

        if(transform.position.x<=leftEdge)   transform.position=initialPos;
    }
}
