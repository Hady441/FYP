using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    TextMeshProUGUI gameOverText;
    TextMeshProUGUI scoreText;
    Button restartButton;
    Button colorPicker;

    int score;

    private void Awake() {
        gameOverText=GameObject.Find("Game Over").GetComponent<TextMeshProUGUI>();
        scoreText=GameObject.Find("Score").GetComponent<TextMeshProUGUI>();
        restartButton=GameObject.Find("Restart").GetComponent<Button>();
        colorPicker=GameObject.Find("Color Picker Button").GetComponent<Button>();

        gameOverText.gameObject.SetActive(false);
        restartButton.gameObject.SetActive(false);
    }

    void Start() {
        score=0;
        scoreText.text=score.ToString();
    }

    public void UpdateScore(){
        score++;
        scoreText.text=score.ToString();
    }

    public void GameOver(){
        gameOverText.gameObject.SetActive(true);
        restartButton.gameObject.SetActive(true);
        colorPicker.gameObject.SetActive(true);
        Time.timeScale=0.0f;
    }

    public void RestartGame(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
