using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    GameObject gameOverText;
    TextMeshProUGUI scoreText;
    GameObject restartButton;
    GameObject colorPicker;
    GameObject backToMenu;

    ColorSwitchStats colorSwitchStats;

    int score;

    private void Awake() {
        gameOverText=GameObject.Find("Game Over");
        scoreText=GameObject.Find("Score").GetComponent<TextMeshProUGUI>();
        restartButton=GameObject.Find("Restart");
        colorPicker=GameObject.Find("Color Picker Button");
        backToMenu=GameObject.Find("Back To Menu");

        gameOverText.gameObject.SetActive(false);
        restartButton.gameObject.SetActive(false);
        backToMenu.SetActive(false);
    }

    void Start() {
        score=0;
        scoreText.text=score.ToString();
        colorSwitchStats=GetComponent<ColorSwitchStats>();
    }

    public void UpdateScore(){
        score++;
        scoreText.text=score.ToString();
    }

    public void GameOver(){
        colorSwitchStats.SetHighScore(score);
        gameOverText.SetActive(true);
        restartButton.SetActive(true);
        colorPicker.SetActive(true);
        backToMenu.SetActive(true);
        Time.timeScale=0.0f;
    }

    public void RestartGame(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void BackToMenu(){
        SceneManager.LoadScene("MainMenu");
    }
}
