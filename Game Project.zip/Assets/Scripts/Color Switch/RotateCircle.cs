using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCircle : MonoBehaviour
{
    float speed=40.0f;

    void Start() {
        int i=Random.Range(-1,1);
        if(i==0)    i=1;
        speed*=i;
    }

    void Update()
    {
        transform.Rotate(Vector3.forward*Time.deltaTime*speed);
    }
}
