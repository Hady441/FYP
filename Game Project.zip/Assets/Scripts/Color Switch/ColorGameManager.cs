using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColorGameManager : MonoBehaviour
{
    public List<GameObject> obstacles;
    public GameObject colorChanger;
    public GameObject player;

    Vector3 playerSpawnPos=new Vector3(0,0,0);
    Vector3 obstacleSpawnPos=new Vector3(0,6.25f,0);
    Vector3 originalColorChangerPosition=new Vector3(0,12.5f,0);

    GameObject lastObjectSpawned;

    void Start()
    {
        Time.timeScale=1.0f;
        Instantiate(player,playerSpawnPos,Quaternion.identity);
        SpawnObstacle(0);
        SpawnColorChanger(0);
    }

    public void SpawnObstacle(float fixPos){//spawn random obstacle
        obstacleSpawnPos=new Vector3(obstacleSpawnPos.x,obstacleSpawnPos.y+fixPos,obstacleSpawnPos.z);

        int obstacleIndex=Random.Range(0,obstacles.Count);
        lastObjectSpawned=Instantiate(obstacles[obstacleIndex],obstacleSpawnPos,Quaternion.identity);
    }

    public void SpawnColorChanger(float fixPos){//spawn color changer collector
        int r=0;
        if(lastObjectSpawned.GetComponent<RotateCircle>()!=null)    r=Random.Range(0,2);

        Vector3 chosenPosition;

        originalColorChangerPosition=new Vector3(originalColorChangerPosition.x,originalColorChangerPosition.y+fixPos,originalColorChangerPosition.z);

        if(r==0)    chosenPosition=originalColorChangerPosition;
        else        chosenPosition=obstacleSpawnPos;

        Instantiate(colorChanger,chosenPosition,Quaternion.identity);
    }
}
