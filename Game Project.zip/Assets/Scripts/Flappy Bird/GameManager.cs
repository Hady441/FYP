using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public Text scoreText;
    public GameObject playButton;
    public GameObject gameOver;
    private int score;

    public GameObject bird;
    private Player player;//references the player script on the bird

    GameObject backToMenu;
    FlappyBirdStats flappyBirdStats;

    private void Start() {
        Vector3 spawnPos = Camera.main.ViewportToWorldPoint(new Vector3(0.2f,0.5f,0f));
        spawnPos=new Vector3(spawnPos.x,spawnPos.y,0);
        
        GameObject b=Instantiate(bird,spawnPos,Quaternion.identity);
        player=b.GetComponent<Player>();

        backToMenu=GameObject.Find("Back To Menu");
        flappyBirdStats=GetComponent<FlappyBirdStats>();
        Pause();
    }

    public void Play(){
        score = 0;
        scoreText.text = score.ToString();

        //hide the UI
        playButton.SetActive(false);
        gameOver.SetActive(false);
        backToMenu.SetActive(false);

        Time.timeScale = 1f;
        player.enabled = true;

        Pipes[] pipes = FindObjectsOfType<Pipes>();

        for(int i=0;i<pipes.Length;i++){
            Destroy(pipes[i].gameObject);
        }
    }

    public void Pause(){
        Time.timeScale = 0f;
        player.enabled = false;
        backToMenu.SetActive(true);
    }

    public void GameOver(){
        gameOver.SetActive(true);
        playButton.SetActive(true);

        flappyBirdStats.SetHighScore(score);

        Pause();
    }

    public void IncreaseScore(){
        score++;
        scoreText.text = score.ToString();
    }

    public void BackToMenu(){
        SceneManager.LoadScene("MainMenu");
    }
}
