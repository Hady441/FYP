using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SizeBackground : MonoBehaviour
{
  private void Start() {
    ResizeSpriteToScreen(); 
  }
     
  private void ResizeSpriteToScreen() { 
    SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>(); 

    if (spriteRenderer == null) return;
    transform.localScale = Vector3.one; 
    float cameraHeight = Camera.main.orthographicSize * 2f;
    float cameraWidth = cameraHeight * Camera.main.aspect;
    float spriteWidth = spriteRenderer.sprite.bounds.size.x; 
    float spriteHeight = spriteRenderer.sprite.bounds.size.y;
            
    Vector3 newScale = transform.localScale;
    newScale.x = cameraWidth / spriteWidth;
    newScale.y = cameraHeight / spriteHeight; 
    transform.localScale = newScale; 
  } 
}