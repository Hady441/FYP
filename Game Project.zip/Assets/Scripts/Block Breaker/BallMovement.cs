using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMovement : MonoBehaviour
{
    public Vector2 inDirection;
    public float speed;
    Vector3 bottomLeft;
    BGameManager bGameManagerScript;

    void Start()
    {
        inDirection = new Vector2(0.5f, 0.5f);
        bottomLeft=Camera.main.ScreenToWorldPoint(Vector3.zero);
        bGameManagerScript=GameObject.Find("GameManager").GetComponent<BGameManager>();
    }

    void FixedUpdate()
    {
        transform.Translate(inDirection * speed * Time.deltaTime);
        if(transform.position.y<bottomLeft.y){
            bGameManagerScript.DiminishLife();
            Destroy(this.gameObject);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        var contactPoint = collision.contacts[0].point;
        Vector2 ballLocation = transform.position;
        var inNormal = (ballLocation - contactPoint).normalized;
        inDirection = Vector2.Reflect(inDirection, inNormal);
    }
}


