using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpinningBrick : Brick
{
    float speedAndDirection;

    private void Awake() {
        speedAndDirection=Random.Range(-15.0f,15.0f);
    }

    void Update()
    {
        transform.Rotate(Vector3.up*speedAndDirection*Time.deltaTime);
    }

    new void OnCollisionEnter2D(Collision2D other) {
        bGameManagerScript.SpawnPowerUp(this.transform.position);
        base.OnCollisionEnter2D(other);
    }
}
