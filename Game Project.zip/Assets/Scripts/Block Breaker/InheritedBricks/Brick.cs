using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brick : SolidBrick
{
    [SerializeField] float hitsToDestroy=1;

    public void OnCollisionEnter2D(Collision2D collision){
        hitsToDestroy--;
        if(hitsToDestroy <= 0)
        {
            bGameManagerScript.DestroyBrick(pos);
        }
    }
}
