using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SolidBrick : MonoBehaviour
{
    [SerializeField] int spawnPercentage=50;

    protected IntPair pos;
    protected BGameManager bGameManagerScript;

    private void Start() {
        bGameManagerScript=GameObject.Find("GameManager").GetComponent<BGameManager>();
        pos=bGameManagerScript.GetBrickPosition(this.gameObject);
    }

    public int GetSpawnPercentage(){
        return spawnPercentage;
    }
}
