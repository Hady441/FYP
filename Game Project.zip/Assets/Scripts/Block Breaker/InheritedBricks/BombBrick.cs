using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombBrick : Brick
{
    private new void OnCollisionEnter2D(Collision2D other){
        base.OnCollisionEnter2D(other);

        int pf=pos.First;
        int ps=pos.Second;
        
        //destroy neighbor blocks
        bGameManagerScript.DestroyBrick(new IntPair(pf-1,ps-1));
        bGameManagerScript.DestroyBrick(new IntPair(pf-1,ps));
        bGameManagerScript.DestroyBrick(new IntPair(pf-1,ps+1));
        bGameManagerScript.DestroyBrick(new IntPair(pf,ps-1));
        bGameManagerScript.DestroyBrick(new IntPair(pf,ps+1));
        bGameManagerScript.DestroyBrick(new IntPair(pf+1,ps-1));
        bGameManagerScript.DestroyBrick(new IntPair(pf+1,ps));
        bGameManagerScript.DestroyBrick(new IntPair(pf+1,ps+1));
    }
}