using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformMovement : MonoBehaviour
{
    BGameManager gameManager;
    private Camera mainCamera;
    BlockBreakerStats bbstats;

    private void Start()
    {
        mainCamera = Camera.main;
        GameObject gm=GameObject.Find("GameManager");
        gameManager=gm.GetComponent<BGameManager>();
        bbstats=gm.GetComponent<BlockBreakerStats>();
    }

    private void Update()
    {
        //follow mouse position horizontally
        Vector2 mousePosition = mainCamera.ScreenToWorldPoint(Input.mousePosition);
        transform.position = new Vector2(mousePosition.x, transform.position.y);
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if(other.TryGetComponent<AddBalls>(out AddBalls ab)){
            gameManager.SpawnBall(ab.GetBallsToSpawn());
            Destroy(other.gameObject);
        }

        if(other.TryGetComponent<PowerUp>(out PowerUp p)) bbstats.CollectPowerup();
    }
}

