using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddBalls : PowerUp
{
    int ballsToSpawn=2;

    public int GetBallsToSpawn(){
        return ballsToSpawn;
    }
}
