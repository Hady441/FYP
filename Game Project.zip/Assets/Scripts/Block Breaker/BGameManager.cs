using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BGameManager : MonoBehaviour
{
    public GameObject[] bricks;
    public List<GameObject> powerups;
    GameObject[,] placedBricksPositions;

    private float screenWidth = Screen.width;
    private float screenHeight = Screen.height;

    public GameObject wallPrefab; 
    public GameObject platform;
    public GameObject ball;

    Vector3 topRight;
    Vector3 bottomLeft;

    public int columnNumber=30;
    public int rowNumber=10;
    int life=0;

    BlockBreakerStats bbStats;

    void Start()
    {
        bbStats=GetComponent<BlockBreakerStats>();
        PlaceWalls();
        PlaceBricks();
        platform=Instantiate(platform, new Vector2(0, -topRight.y),Quaternion.identity);
        SpawnBall(1);
    }
   
    private void PlaceWalls(){
        //get screen corners
        Vector3 screenTopRight = new Vector3(screenWidth, screenHeight, 0f);
        Vector3 screenBottomLeft = new Vector3(0f, 0f, 0f);

        topRight=Camera.main.ScreenToWorldPoint(screenTopRight);
        bottomLeft=Camera.main.ScreenToWorldPoint(screenBottomLeft);
        Quaternion rot = Quaternion.identity * Quaternion.AngleAxis(90, Vector3.forward);

        //place top wall
        float OffSet=wallPrefab.transform.localScale.x/2;
        GameObject topWall=Instantiate(wallPrefab, new Vector3((topRight.x + bottomLeft.x) / 2f, topRight.y+OffSet, 0f), rot);
        Vector3 sc = topWall.transform.localScale;
        topWall.transform.localScale = new Vector3(sc.x, screenWidth, sc.z);
        
        //place side walls
        Instantiate(wallPrefab, new Vector3(bottomLeft.x-OffSet, (topRight.y + bottomLeft.y) / 2f, 0f), Quaternion.identity);
        Instantiate(wallPrefab, new Vector3(topRight.x + OffSet, (topRight.y + bottomLeft.y) / 2f, 0f), Quaternion.identity);
    }

    public IntPair GetBrickPosition(GameObject brick){
        for(int i=0;i<columnNumber;i++){
            for(int j=0;j<rowNumber;j++){
                if(placedBricksPositions[i,j]!=null && placedBricksPositions[i,j].Equals(brick)){
                    return new IntPair(i,j);
                }
            }
        }
        return null;
    }

    void PlaceBricks(){//place bricks in a grid with the corresponding column and row number
        placedBricksPositions=new GameObject[columnNumber,rowNumber];
        FixBorders();
        List<GameObject> bricksWithRates=GetBrickWithRatesList();

        for(int xCounter=0;xCounter<columnNumber;xCounter++){
            for(int yCounter=0;yCounter<rowNumber;yCounter++){
                float x=(xCounter*topRight.x+(columnNumber-xCounter-1)*bottomLeft.x)/columnNumber;
                float y=(yCounter*topRight.y+(rowNumber-yCounter-1)*bottomLeft.y)/rowNumber;

                placedBricksPositions[xCounter,yCounter]=Instantiate(
                    GetBrickToSpawn(bricksWithRates),new Vector3(x,y,0),Quaternion.identity);
            }
        }
    }

    public void DestroyBrick(IntPair position){
        int f=position.First;
        int s=position.Second;
        //check if position outside the grid. used mostly when called from bomb bricks
        if(f>=columnNumber || s>=rowNumber || f<0 || s<0)  return;

        GameObject objToRmv=placedBricksPositions[f,s];
        if(objToRmv==null)  return;//check if brick at this position is already destroyed

        placedBricksPositions[f,s]=null;
        Destroy(objToRmv);
        bbStats.BreakABlock();

        CheckBricks();
    }

    void CheckBricks(){//check if all destructible bricks are destroyed
        for(int i=0;i<columnNumber;i++){
            for(int j=0;j<rowNumber;j++){
                if(placedBricksPositions[i,j]!=null && placedBricksPositions[i,j].TryGetComponent<Brick>(out Brick sb))   return;
            }
        }
        GetComponent<BUIManager>().WinGame();
    }

    List<GameObject> GetBrickWithRatesList(){//make a list with bricks depending on their spawn percentage
        List<GameObject> bricksWithRates=new List<GameObject>();
        foreach(GameObject g in bricks){
            int percentage=g.GetComponent<SolidBrick>().GetSpawnPercentage();
            for(int i=0;i<percentage;i++){
                bricksWithRates.Add(g);
            }
        }
        return bricksWithRates;
    }

    GameObject GetBrickToSpawn(List<GameObject> bricksWithRates){
        return bricksWithRates[UnityEngine.Random.Range(0,bricksWithRates.Count)];
    }

    void FixBorders(){//fix grid positions
        topRight.z=0;
        bottomLeft.z=0;
        topRight.y-=bricks[0].transform.localScale.y;
        bottomLeft.y+=bricks[0].transform.localScale.y;
        topRight.x-=bricks[0].transform.localScale.x;
        bottomLeft.x+=bricks[0].transform.localScale.x;
        bottomLeft.y=(topRight.y+bottomLeft.y)/2;
    }

    public void SpawnBall(int num){
        Transform platTrans=platform.transform;
        for(int i=0;i<num;i++){
            Instantiate(ball,platTrans.position+new Vector3(0,platTrans.localScale.y),Quaternion.identity);
        }
        life+=num;
        bbStats.AddSpawnedBalls(num);
    }

    public void DiminishLife(){
        life--;
        if(life<=0) GetComponent<BUIManager>().GameOver();
    }

    public void SpawnPowerUp(Vector2 pos){
        Instantiate(powerups[Random.Range(0,powerups.Count)],pos,Quaternion.identity);
    }
}