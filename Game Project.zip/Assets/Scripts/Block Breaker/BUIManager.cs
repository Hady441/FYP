using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BUIManager : MonoBehaviour
{
    GameObject colorPicker;
    GameObject gameOverText;
    GameObject restartButton;
    GameObject winScreen;
    GameObject backToMenu;

    private void Awake() {
        Time.timeScale=1.0f;
        colorPicker=GameObject.Find("Color Picker Button");
        gameOverText=GameObject.Find("Game Over");
        restartButton=GameObject.Find("Restart");
        winScreen=GameObject.Find("Win Screen");
        backToMenu=GameObject.Find("Back To Menu");
        backToMenu.SetActive(false);
        gameOverText.SetActive(false);
        restartButton.SetActive(false);
        winScreen.SetActive(false);
    }

    public void WinGame(){
        winScreen.SetActive(true);
        colorPicker.SetActive(true);
        restartButton.SetActive(true);
        backToMenu.SetActive(true);
    }

    public void GameOver(){
        if(winScreen.activeSelf)    return;
        gameOverText.SetActive(true);
        colorPicker.SetActive(true);
        restartButton.SetActive(true);
        backToMenu.SetActive(true);
        Time.timeScale=0;
    }

    public void RestartGame(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void BackToMenu(){
        SceneManager.LoadScene("MainMenu");
    }
}
